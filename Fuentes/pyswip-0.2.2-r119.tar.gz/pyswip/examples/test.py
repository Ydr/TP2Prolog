from pyswip import Prolog, registerForeign

def hello(t):
    print "Hello,", t
hello.arity = 1

registerForeign(hello)

prolog = Prolog()
prolog.assertz("father(michael,john)")
prolog.assertz("father(michael,gina)")
# p = prolog.query("father(michael,X)")
p = prolog.query("father(michael,X), hello(X)")
print list(p)
